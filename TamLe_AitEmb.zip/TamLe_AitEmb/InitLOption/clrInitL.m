function L = clrInitL(dim)

L = eye(dim) - ones(dim, dim)/dim;

end
